#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 5500
#define BUFFER_SIZE 1024

int main() {
    int sock;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE];
    char message[BUFFER_SIZE];
    unsigned long long total_bytes_sent = 0;
    
    // Create socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }
    
    // Configure server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    
    if (inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr) <= 0) {
        perror("Invalid address");
        close(sock);
        exit(EXIT_FAILURE);
    }
    
    // Connect to server
    printf("Connecting to server 127.0.0.1:%d...\n", PORT);
    if (connect(sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        printf("Khong the ket noi toi server 127.0.0.1:%d\n", PORT);
        printf("Hay dam bao server dang chay!\n");
        close(sock);
        exit(EXIT_FAILURE);
    }
    
    printf("Ket noi thanh cong toi server!\n");
    printf("Nhap tin nhan (hoac 'q'/'Q' de thoat)\n\n");
    
    while (1) {
        printf("Nhap tin nhan: ");
        fflush(stdout);
        
        // Read input from user
        if (fgets(message, BUFFER_SIZE, stdin) == NULL) {
            break;
        }
        
        // Remove trailing newline
        message[strcspn(message, "\n")] = '\0';
        
        // Send to server
        ssize_t bytes_sent = send(sock, message, strlen(message), 0);
        if (bytes_sent < 0) {
            perror("Send failed");
            break;
        }
        
        total_bytes_sent += bytes_sent;
        
        // Check if user wants to quit
        if (strcmp(message, "q") == 0 || strcmp(message, "Q") == 0) {
            printf("Dang dong ket noi...\n");
            break;
        }
        
        // Receive response from server
        memset(buffer, 0, BUFFER_SIZE);
        ssize_t bytes_received = recv(sock, buffer, BUFFER_SIZE - 1, 0);
        
        if (bytes_received <= 0) {
            printf("Server da dong ket noi\n");
            break;
        }
        
        printf("Server: %s\n\n", buffer);
    }
    
    close(sock);
    
    printf("\n=== Thong ke ===\n");
    printf("Tong so byte da gui toi server: %llu bytes\n", total_bytes_sent);
    
    return 0;
}
