#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <ctype.h>

#define PORT 5500
#define BUFFER_SIZE 1024
#define BACKLOG 10

typedef struct {
    int client_sock;
    struct sockaddr_in client_addr;
    int thread_id;
} client_info_t;

int active_threads = 0;
pthread_mutex_t thread_count_mutex = PTHREAD_MUTEX_INITIALIZER;

void to_uppercase(char *str) {
    for (int i = 0; str[i]; i++) {
        str[i] = toupper((unsigned char)str[i]);
    }
}

void *handle_client(void *arg) {
    client_info_t *client = (client_info_t *)arg;
    char buffer[BUFFER_SIZE];
    ssize_t bytes_received;
    
    pthread_mutex_lock(&thread_count_mutex);
    active_threads++;
    int thread_num = active_threads;
    pthread_mutex_unlock(&thread_count_mutex);
    
    printf("[Thread %d] New connection from %s:%d\n",
           thread_num,
           inet_ntoa(client->client_addr.sin_addr),
           ntohs(client->client_addr.sin_port));
    
    while (1) {
        memset(buffer, 0, BUFFER_SIZE);
        bytes_received = recv(client->client_sock, buffer, BUFFER_SIZE - 1, 0);
        
        if (bytes_received <= 0) {
            printf("[Thread %d] Client disconnected\n", thread_num);
            break;
        }
        
        // Remove trailing newline if present
        buffer[strcspn(buffer, "\n")] = '\0';
        
        printf("[Thread %d] Received: %s\n", thread_num, buffer);
        
        // Check for quit command
        if (strcmp(buffer, "q") == 0 || strcmp(buffer, "Q") == 0) {
            printf("[Thread %d] Client sent quit command\n", thread_num);
            break;
        }
        
        // Convert to uppercase
        to_uppercase(buffer);
        
        // Send back to client
        ssize_t bytes_sent = send(client->client_sock, buffer, strlen(buffer), 0);
        if (bytes_sent < 0) {
            perror("Send failed");
            break;
        }
        
        printf("[Thread %d] Sent: %s\n", thread_num, buffer);
    }
    
    close(client->client_sock);
    
    pthread_mutex_lock(&thread_count_mutex);
    active_threads--;
    pthread_mutex_unlock(&thread_count_mutex);
    
    printf("[Thread %d] Connection closed (Active threads: %d)\n", thread_num, active_threads);
    
    free(client);
    pthread_exit(NULL);
}

int main() {
    int server_sock, client_sock;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);
    pthread_t thread_id;
    
    // Create socket
    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (server_sock < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }
    
    // Set socket options to reuse address
    int opt = 1;
    if (setsockopt(server_sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        perror("Setsockopt failed");
        close(server_sock);
        exit(EXIT_FAILURE);
    }
    
    // Configure server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    server_addr.sin_port = htons(PORT);
    
    // Bind socket
    if (bind(server_sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(server_sock);
        exit(EXIT_FAILURE);
    }
    
    // Listen for connections
    if (listen(server_sock, BACKLOG) < 0) {
        perror("Listen failed");
        close(server_sock);
        exit(EXIT_FAILURE);
    }
    
    printf("=== Multithreaded Message Server ===\n");
    printf("Listening on 127.0.0.1:%d\n", PORT);
    printf("Waiting for client connections...\n\n");
    
    while (1) {
        // Accept client connection
        client_sock = accept(server_sock, (struct sockaddr*)&client_addr, &addr_len);
        if (client_sock < 0) {
            perror("Accept failed");
            continue;
        }
        
        // Allocate client info structure
        client_info_t *client = malloc(sizeof(client_info_t));
        if (client == NULL) {
            perror("Memory allocation failed");
            close(client_sock);
            continue;
        }
        
        client->client_sock = client_sock;
        client->client_addr = client_addr;
        
        // Create thread to handle client
        if (pthread_create(&thread_id, NULL, handle_client, (void *)client) != 0) {
            perror("Thread creation failed");
            close(client_sock);
            free(client);
            continue;
        }
        
        // Detach thread to auto-cleanup when finished
        pthread_detach(thread_id);
    }
    
    close(server_sock);
    pthread_mutex_destroy(&thread_count_mutex);
    
    return 0;
}
