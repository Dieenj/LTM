#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>

#define BUFFER_SIZE 1024
#define MAX_ACCOUNTS 100
#define MAX_SESSIONS 100
#define MAX_USERNAME 50
#define MAX_PASSWORD 50
#define MAX_LOGIN_ATTEMPTS 5

typedef struct {
    char username[MAX_USERNAME];
    char password[MAX_PASSWORD];
    int status; // 0: blocked, 1: active
    int login_attempts;
} account_t;

typedef struct {
    char username[MAX_USERNAME];
    char ip_address[INET_ADDRSTRLEN];
    int port;
    time_t login_time;
    int is_active;
} session_t;

typedef struct {
    int client_sock;
    struct sockaddr_in client_addr;
} client_info_t;

account_t accounts[MAX_ACCOUNTS];
int account_count = 0;

session_t sessions[MAX_SESSIONS];
int session_count = 0;

pthread_mutex_t account_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t session_mutex = PTHREAD_MUTEX_INITIALIZER;

// Load accounts from file
void load_accounts() {
    FILE *file = fopen("account.txt", "r");
    if (file == NULL) {
        printf("Warning: account.txt not found. Creating default accounts...\n");
        // Create default account file
        file = fopen("account.txt", "w");
        if (file != NULL) {
            fprintf(file, "admin password123 1\n");
            fprintf(file, "user1 pass1 1\n");
            fprintf(file, "user2 pass2 1\n");
            fprintf(file, "blocked blockedpass 0\n");
            fclose(file);
        }
        file = fopen("account.txt", "r");
        if (file == NULL) {
            perror("Cannot create account.txt");
            exit(EXIT_FAILURE);
        }
    }
    
    pthread_mutex_lock(&account_mutex);
    account_count = 0;
    
    while (fscanf(file, "%s %s %d", 
                  accounts[account_count].username,
                  accounts[account_count].password,
                  &accounts[account_count].status) == 3) {
        accounts[account_count].login_attempts = 0;
        account_count++;
        if (account_count >= MAX_ACCOUNTS) break;
    }
    
    fclose(file);
    pthread_mutex_unlock(&account_mutex);
    
    printf("Loaded %d accounts from account.txt\n", account_count);
}

// Save accounts to file
void save_accounts() {
    pthread_mutex_lock(&account_mutex);
    
    FILE *file = fopen("account.txt", "w");
    if (file == NULL) {
        perror("Cannot save accounts");
        pthread_mutex_unlock(&account_mutex);
        return;
    }
    
    for (int i = 0; i < account_count; i++) {
        fprintf(file, "%s %s %d\n",
                accounts[i].username,
                accounts[i].password,
                accounts[i].status);
    }
    
    fclose(file);
    pthread_mutex_unlock(&account_mutex);
}

// Find account by username
account_t* find_account(const char *username) {
    for (int i = 0; i < account_count; i++) {
        if (strcmp(accounts[i].username, username) == 0) {
            return &accounts[i];
        }
    }
    return NULL;
}

// Add session
void add_session(const char *username, const char *ip, int port) {
    pthread_mutex_lock(&session_mutex);
    
    if (session_count < MAX_SESSIONS) {
        strncpy(sessions[session_count].username, username, MAX_USERNAME - 1);
        strncpy(sessions[session_count].ip_address, ip, INET_ADDRSTRLEN - 1);
        sessions[session_count].port = port;
        sessions[session_count].login_time = time(NULL);
        sessions[session_count].is_active = 1;
        session_count++;
    }
    
    pthread_mutex_unlock(&session_mutex);
}

// Remove session
void remove_session(const char *username, const char *ip, int port) {
    pthread_mutex_lock(&session_mutex);
    
    for (int i = 0; i < session_count; i++) {
        if (strcmp(sessions[i].username, username) == 0 &&
            strcmp(sessions[i].ip_address, ip) == 0 &&
            sessions[i].port == port) {
            sessions[i].is_active = 0;
            break;
        }
    }
    
    pthread_mutex_unlock(&session_mutex);
}

// Get sessions for a user
void get_user_sessions(const char *username, char *response) {
    pthread_mutex_lock(&session_mutex);
    
    sprintf(response, "=== Sessions for %s ===\n", username);
    int count = 0;
    
    for (int i = 0; i < session_count; i++) {
        if (sessions[i].is_active && strcmp(sessions[i].username, username) == 0) {
            char time_str[64];
            strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S",
                    localtime(&sessions[i].login_time));
            
            char temp[256];
            sprintf(temp, "%d. IP: %s:%d | Login time: %s\n",
                   ++count, sessions[i].ip_address, sessions[i].port, time_str);
            strcat(response, temp);
        }
    }
    
    if (count == 0) {
        strcat(response, "No active sessions found.\n");
    }
    
    pthread_mutex_unlock(&session_mutex);
}

// Get online users
void get_online_users(char *response) {
    pthread_mutex_lock(&session_mutex);
    
    sprintf(response, "=== Online Users ===\n");
    char listed[MAX_ACCOUNTS][MAX_USERNAME];
    int listed_count = 0;
    int found;
    
    for (int i = 0; i < session_count; i++) {
        if (!sessions[i].is_active) continue;
        
        // Check if already listed
        found = 0;
        for (int j = 0; j < listed_count; j++) {
            if (strcmp(listed[j], sessions[i].username) == 0) {
                found = 1;
                break;
            }
        }
        
        if (!found) {
            strncpy(listed[listed_count], sessions[i].username, MAX_USERNAME - 1);
            listed_count++;
            
            // Count connections for this user
            int conn_count = 0;
            for (int k = 0; k < session_count; k++) {
                if (sessions[k].is_active &&
                    strcmp(sessions[k].username, sessions[i].username) == 0) {
                    conn_count++;
                }
            }
            
            char temp[128];
            sprintf(temp, "- %s (%d connection%s)\n",
                   sessions[i].username, conn_count, conn_count > 1 ? "s" : "");
            strcat(response, temp);
        }
    }
    
    if (listed_count == 0) {
        strcat(response, "No users online.\n");
    }
    
    pthread_mutex_unlock(&session_mutex);
}

void *handle_client(void *arg) {
    client_info_t *client = (client_info_t *)arg;
    char buffer[BUFFER_SIZE];
    char response[BUFFER_SIZE];
    char logged_in_user[MAX_USERNAME] = "";
    int is_logged_in = 0;
    
    char client_ip[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &(client->client_addr.sin_addr), client_ip, INET_ADDRSTRLEN);
    int client_port = ntohs(client->client_addr.sin_port);
    
    printf("[Thread] Client connected from %s:%d\n", client_ip, client_port);
    
    // Send welcome message
    strcpy(response, "=== Login System ===\nCommands: login <username> <password> | logout | sessions | online | quit\n");
    send(client->client_sock, response, strlen(response), 0);
    
    while (1) {
        memset(buffer, 0, BUFFER_SIZE);
        ssize_t bytes_received = recv(client->client_sock, buffer, BUFFER_SIZE - 1, 0);
        
        if (bytes_received <= 0) {
            break;
        }
        
        buffer[strcspn(buffer, "\n")] = '\0';
        
        printf("[%s:%d] Command: %s\n", client_ip, client_port, buffer);
        
        // Parse command
        char command[BUFFER_SIZE];
        char username[MAX_USERNAME];
        char password[MAX_PASSWORD];
        
        int parsed = sscanf(buffer, "%s %s %s", command, username, password);
        
        if (strcmp(command, "login") == 0 && parsed == 3) {
            if (is_logged_in) {
                strcpy(response, "ERROR: Already logged in as ");
                strcat(response, logged_in_user);
                strcat(response, "\n");
            } else {
                pthread_mutex_lock(&account_mutex);
                account_t *acc = find_account(username);
                
                if (acc == NULL) {
                    strcpy(response, "ERROR: Account does not exist\n");
                } else if (acc->status == 0) {
                    strcpy(response, "ERROR: Account is blocked\n");
                } else if (strcmp(acc->password, password) != 0) {
                    acc->login_attempts++;
                    if (acc->login_attempts >= MAX_LOGIN_ATTEMPTS) {
                        acc->status = 0;
                        save_accounts();
                        strcpy(response, "ERROR: Account blocked due to too many failed login attempts\n");
                    } else {
                        sprintf(response, "ERROR: Incorrect password (Attempt %d/%d)\n",
                               acc->login_attempts, MAX_LOGIN_ATTEMPTS);
                    }
                } else {
                    // Successful login
                    acc->login_attempts = 0;
                    strncpy(logged_in_user, username, MAX_USERNAME - 1);
                    is_logged_in = 1;
                    add_session(username, client_ip, client_port);
                    sprintf(response, "SUCCESS: Logged in as %s\n", username);
                }
                
                pthread_mutex_unlock(&account_mutex);
            }
        } else if (strcmp(command, "logout") == 0) {
            if (!is_logged_in) {
                strcpy(response, "ERROR: Not logged in\n");
            } else {
                remove_session(logged_in_user, client_ip, client_port);
                sprintf(response, "SUCCESS: Logged out from %s\n", logged_in_user);
                logged_in_user[0] = '\0';
                is_logged_in = 0;
            }
        } else if (strcmp(command, "sessions") == 0) {
            if (!is_logged_in) {
                strcpy(response, "ERROR: Must be logged in\n");
            } else {
                get_user_sessions(logged_in_user, response);
            }
        } else if (strcmp(command, "online") == 0) {
            if (!is_logged_in) {
                strcpy(response, "ERROR: Must be logged in\n");
            } else {
                get_online_users(response);
            }
        } else if (strcmp(command, "quit") == 0) {
            if (is_logged_in) {
                remove_session(logged_in_user, client_ip, client_port);
            }
            strcpy(response, "Goodbye!\n");
            send(client->client_sock, response, strlen(response), 0);
            break;
        } else {
            strcpy(response, "ERROR: Invalid command\n");
            strcat(response, "Commands: login <username> <password> | logout | sessions | online | quit\n");
        }
        
        send(client->client_sock, response, strlen(response), 0);
    }
    
    if (is_logged_in) {
        remove_session(logged_in_user, client_ip, client_port);
    }
    
    close(client->client_sock);
    printf("[Thread] Client disconnected: %s:%d\n", client_ip, client_port);
    
    free(client);
    pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <Port_Number>\n", argv[0]);
        printf("Example: %s 5500\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    int port = atoi(argv[1]);
    if (port <= 0 || port > 65535) {
        printf("Invalid port number. Must be between 1-65535\n");
        exit(EXIT_FAILURE);
    }
    
    load_accounts();
    
    int server_sock;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);
    pthread_t thread_id;
    
    // Create socket
    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (server_sock < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }
    
    // Set socket options
    int opt = 1;
    if (setsockopt(server_sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        perror("Setsockopt failed");
        close(server_sock);
        exit(EXIT_FAILURE);
    }
    
    // Configure server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(port);
    
    // Bind
    if (bind(server_sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(server_sock);
        exit(EXIT_FAILURE);
    }
    
    // Listen
    if (listen(server_sock, 10) < 0) {
        perror("Listen failed");
        close(server_sock);
        exit(EXIT_FAILURE);
    }
    
    printf("=== Multithreaded Login Server ===\n");
    printf("Listening on port %d\n", port);
    printf("Waiting for connections...\n\n");
    
    while (1) {
        int client_sock = accept(server_sock, (struct sockaddr*)&client_addr, &addr_len);
        if (client_sock < 0) {
            perror("Accept failed");
            continue;
        }
        
        client_info_t *client = malloc(sizeof(client_info_t));
        if (client == NULL) {
            perror("Memory allocation failed");
            close(client_sock);
            continue;
        }
        
        client->client_sock = client_sock;
        client->client_addr = client_addr;
        
        if (pthread_create(&thread_id, NULL, handle_client, (void *)client) != 0) {
            perror("Thread creation failed");
            close(client_sock);
            free(client);
            continue;
        }
        
        pthread_detach(thread_id);
    }
    
    close(server_sock);
    pthread_mutex_destroy(&account_mutex);
    pthread_mutex_destroy(&session_mutex);
    
    return 0;
}
