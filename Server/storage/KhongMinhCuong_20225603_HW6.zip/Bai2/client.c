#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define BUFFER_SIZE 2048

void print_help() {
    printf("\n=== Available Commands ===\n");
    printf("login <username> <password> - Login to your account\n");
    printf("logout                       - Logout from current account\n");
    printf("sessions                     - View all active sessions for your account\n");
    printf("online                       - View all online users\n");
    printf("quit                         - Exit the program\n");
    printf("==========================\n\n");
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <IP_Address> <Port_Number>\n", argv[0]);
        printf("Example: %s 127.0.0.1 5500\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    char *server_ip = argv[1];
    int port = atoi(argv[2]);
    
    if (port <= 0 || port > 65535) {
        printf("Invalid port number. Must be between 1-65535\n");
        exit(EXIT_FAILURE);
    }
    
    int sock;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE];
    char command[BUFFER_SIZE];
    
    // Create socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }
    
    // Configure server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    
    if (inet_pton(AF_INET, server_ip, &server_addr.sin_addr) <= 0) {
        printf("Invalid address: %s\n", server_ip);
        close(sock);
        exit(EXIT_FAILURE);
    }
    
    // Connect to server
    printf("Connecting to %s:%d...\n", server_ip, port);
    if (connect(sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        printf("Cannot connect to server %s:%d\n", server_ip, port);
        printf("Make sure the server is running!\n");
        close(sock);
        exit(EXIT_FAILURE);
    }
    
    printf("Connected successfully!\n\n");
    
    // Receive welcome message
    memset(buffer, 0, BUFFER_SIZE);
    recv(sock, buffer, BUFFER_SIZE - 1, 0);
    printf("%s\n", buffer);
    
    print_help();
    
    while (1) {
        printf("Command> ");
        fflush(stdout);
        
        // Read command
        if (fgets(command, BUFFER_SIZE, stdin) == NULL) {
            break;
        }
        
        command[strcspn(command, "\n")] = '\0';
        
        // Skip empty commands
        if (strlen(command) == 0) {
            continue;
        }
        
        // Show help
        if (strcmp(command, "help") == 0) {
            print_help();
            continue;
        }
        
        // Send command to server
        ssize_t bytes_sent = send(sock, command, strlen(command), 0);
        if (bytes_sent < 0) {
            perror("Send failed");
            break;
        }
        
        // Check if quit command
        if (strncmp(command, "quit", 4) == 0) {
            // Receive goodbye message
            memset(buffer, 0, BUFFER_SIZE);
            recv(sock, buffer, BUFFER_SIZE - 1, 0);
            printf("%s", buffer);
            break;
        }
        
        // Receive response
        memset(buffer, 0, BUFFER_SIZE);
        ssize_t bytes_received = recv(sock, buffer, BUFFER_SIZE - 1, 0);
        
        if (bytes_received <= 0) {
            printf("Server disconnected\n");
            break;
        }
        
        printf("%s\n", buffer);
    }
    
    close(sock);
    printf("Disconnected from server.\n");
    
    return 0;
}
