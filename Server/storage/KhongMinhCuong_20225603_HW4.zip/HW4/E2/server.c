
/* Simple file server that accepts a filename line, replies whether
   the file exists, and if not, accepts a filesize line and then
   receives exactly that many bytes and writes them to STORAGE.
   Responds with specific messages required by the assignment. */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <errno.h>

#define BACKLOG 5
#define STORAGE "./Storage/"
#define MAX_FILE_SIZE (100ULL * 1024ULL * 1024ULL) // 100 MB
#define RECV_BUF 8192

// read a line (terminated by '\n') from sock into buf (null-terminated, without '\n')
ssize_t recv_line(int sock, char *buf, size_t maxlen){
	size_t i = 0;
	while(i < maxlen - 1){
		ssize_t r = recv(sock, buf + i, 1, 0);
		if(r == 1){
			if(buf[i] == '\n'){
				buf[i] = '\0';
				return (ssize_t)i;
			}
			i += 1;
			continue;
		}else if(r == 0){
			// connection closed
			return -1;
		}else{
			// error
			if(errno == EINTR) continue;
			return -1;
		}
	}
	buf[i] = '\0';
	return (ssize_t)i;
}

int ensure_storage(){
	struct stat st = {0};
	if(stat(STORAGE, &st) == -1){
		if(mkdir(STORAGE, 0755) == -1){
			return -1;
		}
	}
	return 0;
}

int main(int argc, char **argv){
	if(argc != 2){
		fprintf(stderr, "Usage: %s Port_Number\n", argv[0]);
		return 1;
	}
	int port = atoi(argv[1]);
	if(port <= 0){
		fprintf(stderr, "Invalid port\n");
		return 1;
	}

	if(ensure_storage() != 0){
		perror("ensure_storage");
		return 1;
	}

	int listen_sock = socket(AF_INET, SOCK_STREAM, 0);
	if(listen_sock < 0){ perror("socket"); return 1; }

	struct sockaddr_in server;
	memset(&server, 0, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_port = htons(port);
	server.sin_addr.s_addr = htonl(INADDR_ANY);

	if(bind(listen_sock, (struct sockaddr*)&server, sizeof(server)) < 0){ perror("bind"); close(listen_sock); return 1; }
	if(listen(listen_sock, BACKLOG) < 0){ perror("listen"); close(listen_sock); return 1; }

	printf("Server listening on port %d\n", port);

	while(1){
		struct sockaddr_in client;
		socklen_t clilen = sizeof(client);
		int conn = accept(listen_sock, (struct sockaddr*)&client, &clilen);
		if(conn < 0){ perror("accept"); continue; }
		printf("Connection from %s\n", inet_ntoa(client.sin_addr));

		while(1){
			char filename[1024];
			ssize_t n = recv_line(conn, filename, sizeof(filename));
			if(n <= 0) break; // connection closed or error
			if(strlen(filename) == 0) {
				// empty line: ignore or continue
				continue;
			}
			// construct path
			char path[2048];
			snprintf(path, sizeof(path), "%s%s", STORAGE, filename);

			// check existence
			FILE *f = fopen(path, "rb");
			if(f){
				fclose(f);
				const char *msg = "Error: File is existent on server\n";
				send(conn, msg, strlen(msg), 0);
				continue; // wait for next filename
			}

			// reply OK
			const char *ok = "OK\n";
			send(conn, ok, strlen(ok), 0);

			// read filesize line
			char sizebuf[64];
			ssize_t rn = recv_line(conn, sizebuf, sizeof(sizebuf));
			if(rn <= 0){
				// connection error
				break;
			}
			unsigned long long filesize = strtoull(sizebuf, NULL, 10);
			if(filesize == 0 && strcmp(sizebuf, "0") != 0){
				// invalid size
				const char *msg = "Error: File tranfering is interupted\n";
				send(conn, msg, strlen(msg), 0);
				continue;
			}
			if(filesize > MAX_FILE_SIZE){
				const char *msg = "Error: File is too large\n";
				send(conn, msg, strlen(msg), 0);
				continue;
			}

			// receive file data
			FILE *out = fopen(path, "wb");
			if(!out){
				const char *msg = "Error: Cannot create file on server\n";
				send(conn, msg, strlen(msg), 0);
				continue;
			}

			unsigned long long received = 0;
			char buf[RECV_BUF];
			int error_happened = 0;
			while(received < filesize){
				size_t toread = (filesize - received) < sizeof(buf) ? (size_t)(filesize - received) : sizeof(buf);
				ssize_t r = recv(conn, buf, toread, 0);
				if(r <= 0){
					error_happened = 1;
					break;
				}
				size_t w = fwrite(buf, 1, r, out);
				if(w != (size_t)r){ error_happened = 1; break; }
				received += (unsigned long long)r;
			}
			fclose(out);
			if(error_happened || received != filesize){
				// remove partial file
				remove(path);
				const char *msg = "Error: File tranfering is interupted\n";
				send(conn, msg, strlen(msg), 0);
				continue;
			}

			// success
			const char *succ = "Successful transfering\n";
			send(conn, succ, strlen(succ), 0);
		}
		close(conn);
	}

	close(listen_sock);
	return 0;
}