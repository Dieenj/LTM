#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <ctype.h>

#define RECV_BUF_SIZE 4096

void process_message_and_respond(int sock, const char *msg, size_t len){
	char digits[RECV_BUF_SIZE];
	char letters[RECV_BUF_SIZE];
	size_t di = 0, li = 0;
	for(size_t i = 0; i < len; ++i){
		unsigned char c = msg[i];
		if(isdigit(c)){
			if(di + 1 < sizeof(digits)) digits[di++] = c;
		}else if(isalpha(c)){
			if(li + 1 < sizeof(letters)) letters[li++] = c;
		}else{
			const char *err = "Error\n"; // single-line error
			send(sock, err, strlen(err), 0);
			return;
		}
	}
	digits[di] = '\0';
	letters[li] = '\0';
	// Send digits line then letters line (each terminated by \n)
	send(sock, digits, strlen(digits), 0);
	send(sock, "\n", 1, 0);
	send(sock, letters, strlen(letters), 0);
	send(sock, "\n", 1, 0);
}

int main(int argc, char *argv[]){
	if(argc != 2){
		fprintf(stderr, "Usage: %s Port_Number\n", argv[0]);
		return EXIT_FAILURE;
	}

	int sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd < 0){
		perror("socket");
		return 1;
	}

	struct sockaddr_in serverAddr;
	memset(&serverAddr, 0, sizeof(serverAddr));
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(atoi(argv[1]));
	serverAddr.sin_addr.s_addr = htonl(INADDR_ANY); // accept connections from any interface

	if(bind(sockfd, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0){
		perror("bind");
		close(sockfd);
		return 1;
	}
	printf("[+]Bind to port %s\n", argv[1]);

	if(listen(sockfd, 10) < 0){
		perror("listen");
		close(sockfd);
		return 1;
	}
	printf("[+]Listening....\n");

	while(1){
		struct sockaddr_in clientAddr;
		socklen_t addr_size = sizeof(clientAddr);
		int newsock = accept(sockfd, (struct sockaddr*)&clientAddr, &addr_size);
		if(newsock < 0){
			perror("accept");
			continue;
		}
		printf("Connection accepted from %s:%d\n", inet_ntoa(clientAddr.sin_addr), ntohs(clientAddr.sin_port));

		char buffer[RECV_BUF_SIZE];
		size_t buflen = 0;
		while(1){
			char tmp[1024];
			ssize_t r = recv(newsock, tmp, sizeof(tmp), 0);
			if(r <= 0){
				printf("Disconnected from %s:%d\n", inet_ntoa(clientAddr.sin_addr), ntohs(clientAddr.sin_port));
				break;
			}
			if(buflen + (size_t)r > sizeof(buffer)){
				// input too long -> send error and reset buffer
				const char *err = "Error\n";
				send(newsock, err, strlen(err), 0);
				buflen = 0;
				continue;
			}
			memcpy(buffer + buflen, tmp, r);
			buflen += r;
			// process full lines
			char *newline;
			while((newline = memchr(buffer, '\n', buflen)) != NULL){
				size_t msglen = newline - buffer; // exclude newline
				if(msglen == 0){
					// empty message: treat as client termination request
					close(newsock);
					goto next_connection;
				}
				// process single message
				process_message_and_respond(newsock, buffer, msglen);
				// remove processed message from buffer
				size_t remaining = buflen - (msglen + 1);
				memmove(buffer, newline + 1, remaining);
				buflen = remaining;
			}
		}
		close(newsock);
	next_connection: ;
	}

	close(sockfd);
	return 0;
}